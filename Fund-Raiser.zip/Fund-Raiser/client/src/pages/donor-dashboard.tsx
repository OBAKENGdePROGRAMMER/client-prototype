import DonorDashboard from "@/components/DonorDashboard";

export default function DonorDashboardPage() {
  return <DonorDashboard />;
}
