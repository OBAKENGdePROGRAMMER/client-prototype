import MenteeDashboard from "@/components/MenteeDashboard";

export default function MenteeDashboardPage() {
  return <MenteeDashboard />;
}
