import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/ThemeProvider";
import { Menu, X, Sun, Moon, ChevronDown, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  transparent?: boolean;
  onLoginClick?: () => void;
  onRegisterClick?: () => void;
}

export default function Header({ transparent = false, onLoginClick, onRegisterClick }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const [location] = useLocation();

  const navItems = [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Events", href: "/events" },
    { label: "Resources", href: "/resources" },
    { label: "Contact", href: "/contact" },
  ];

  const headerBg = transparent
    ? "bg-transparent"
    : "bg-background/95 backdrop-blur-sm border-b border-border";

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 ${headerBg} transition-colors duration-200`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-md bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">A</span>
            </div>
            <div className="hidden sm:block">
              <span className={`font-bold text-lg ${transparent ? "text-white" : "text-foreground"}`}>
                ABM Network
              </span>
              <p className={`text-xs ${transparent ? "text-white/80" : "text-muted-foreground"}`}>
                Sci-Tech SF
              </p>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`${
                    transparent
                      ? "text-white hover:bg-white/10"
                      : location === item.href
                      ? "bg-accent"
                      : ""
                  }`}
                  data-testid={`nav-${item.label.toLowerCase()}`}
                >
                  {item.label}
                </Button>
              </Link>
            ))}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className={transparent ? "text-white hover:bg-white/10" : ""}
                  data-testid="nav-dashboards"
                >
                  Dashboards <ChevronDown className="ml-1 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/mentor" data-testid="nav-mentor-dashboard">Mentor Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/mentee" data-testid="nav-mentee-dashboard">Mentee Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/admin" data-testid="nav-admin-dashboard">Admin Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/dashboard/donor" data-testid="nav-donor-dashboard">Donor Dashboard</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className={transparent ? "text-white hover:bg-white/10" : ""}
              data-testid="button-theme-toggle"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>

            <div className="hidden sm:flex items-center gap-2">
              <Button
                variant={transparent ? "outline" : "ghost"}
                size="sm"
                onClick={onLoginClick}
                className={transparent ? "text-white border-white/30 hover:bg-white/10" : ""}
                data-testid="button-login"
              >
                Log In
              </Button>
              <Button
                size="sm"
                onClick={onRegisterClick}
                data-testid="button-register"
              >
                <User className="h-4 w-4 mr-2" />
                Join Program
              </Button>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className={`md:hidden ${transparent ? "text-white" : ""}`}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border bg-background">
            <nav className="flex flex-col gap-1">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <Button
                    variant="ghost"
                    className="w-full justify-start"
                    onClick={() => setMobileMenuOpen(false)}
                    data-testid={`mobile-nav-${item.label.toLowerCase()}`}
                  >
                    {item.label}
                  </Button>
                </Link>
              ))}
              <div className="border-t border-border my-2" />
              <Button variant="ghost" className="w-full justify-start" onClick={onLoginClick}>
                Log In
              </Button>
              <Button className="w-full mt-2" onClick={onRegisterClick}>
                Join Program
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
