import { ThemeProvider } from "../ThemeProvider";
import MatchCard from "../MatchCard";

export default function MatchCardExample() {
  return (
    <ThemeProvider>
      <MatchCard
        mentor={{ id: "1", name: "Sarah Johnson", role: "3rd Year Engineering", institution: "SMU" }}
        mentee={{ id: "2", name: "Lerato Ndlovu", role: "Grade 10 Student", institution: "Pretoria High" }}
        matchScore={87}
        matchCriteria={["Engineering Interest", "Female Mentor Preference", "Weekday Availability"]}
        status="pending"
        onAccept={() => console.log("Match accepted")}
        onReject={() => console.log("Match rejected")}
        onRematch={() => console.log("Finding new match")}
      />
    </ThemeProvider>
  );
}
