import { ThemeProvider } from "../ThemeProvider";
import ServicesSection from "../ServicesSection";

export default function ServicesSectionExample() {
  return (
    <ThemeProvider>
      <ServicesSection />
    </ThemeProvider>
  );
}
