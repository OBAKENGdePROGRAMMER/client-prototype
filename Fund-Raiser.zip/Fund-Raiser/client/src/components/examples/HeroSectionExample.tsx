import { ThemeProvider } from "../ThemeProvider";
import HeroSection from "../HeroSection";

export default function HeroSectionExample() {
  return (
    <ThemeProvider>
      <HeroSection
        onBecomeMentor={() => console.log("Become mentor clicked")}
        onLearnMore={() => console.log("Learn more clicked")}
      />
    </ThemeProvider>
  );
}
