import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";
import mentorImage from "@assets/generated_images/mentor_mentee_session_photo.png";

interface ProgramOverviewProps {
  onJoinProgram?: () => void;
}

const programFeatures = [
  "One-on-one mentorship matching",
  "Structured session tracking",
  "Access to learning resources",
  "Psychosocial support available",
  "Career guidance and counselling",
  "Regular workshops and events",
];

export default function ProgramOverview({ onJoinProgram }: ProgramOverviewProps) {
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              About the Adopt-a-Buddy Mentorship Program
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              The ABM Program connects university students with high school learners, 
              providing guidance, support, and inspiration for their educational journey 
              and future careers in STEMI fields.
            </p>
            <p className="text-muted-foreground mb-8">
              Our structured approach ensures meaningful mentorship relationships with 
              regular sessions, progress tracking, and access to professional support 
              when needed. Together, we're building the next generation of innovators 
              and leaders.
            </p>

            <ul className="space-y-3 mb-8">
              {programFeatures.map((feature, index) => (
                <li key={index} className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <Button size="lg" onClick={onJoinProgram} data-testid="button-join-program">
              Join the Program
            </Button>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] rounded-lg overflow-hidden">
              <img
                src={mentorImage}
                alt="Mentor and mentee in a productive session"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-card rounded-lg p-4 shadow-lg border border-border">
              <div className="flex items-center gap-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary">95%</p>
                  <p className="text-sm text-muted-foreground">Satisfaction Rate</p>
                </div>
                <div className="w-px h-12 bg-border" />
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary">3.5</p>
                  <p className="text-sm text-muted-foreground">Avg Sessions/Month</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
