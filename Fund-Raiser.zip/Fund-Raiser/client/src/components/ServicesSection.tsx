import { Card, CardContent } from "@/components/ui/card";
import { Users, GraduationCap, Building2, Trophy, Heart, Target, Lightbulb, HandHeart } from "lucide-react";

const services = [
  {
    icon: Users,
    title: "Youth Development",
    description: "Empowering young people with skills, knowledge, and opportunities for personal growth.",
    color: "text-blue-500",
  },
  {
    icon: GraduationCap,
    title: "Student Development",
    description: "Academic support and guidance for students pursuing STEMI education pathways.",
    color: "text-green-500",
  },
  {
    icon: Building2,
    title: "Community Development",
    description: "Building stronger communities through collaborative initiatives and outreach programs.",
    color: "text-purple-500",
  },
  {
    icon: Trophy,
    title: "Sports Development",
    description: "Promoting physical wellness and teamwork through organized sporting activities.",
    color: "text-orange-500",
  },
  {
    icon: Heart,
    title: "Counselling",
    description: "Professional support for mental health, well-being, and personal challenges.",
    color: "text-red-500",
  },
  {
    icon: Target,
    title: "Coaching",
    description: "Goal-oriented coaching to help individuals achieve their full potential.",
    color: "text-teal-500",
  },
  {
    icon: Lightbulb,
    title: "Mentorship",
    description: "One-on-one guidance connecting experienced mentors with aspiring mentees.",
    color: "text-yellow-500",
  },
  {
    icon: HandHeart,
    title: "Volunteer Programs",
    description: "Opportunities to give back and make a meaningful impact in your community.",
    color: "text-pink-500",
  },
];

export default function ServicesSection() {
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive programs designed to nurture growth, foster connections, 
            and create lasting positive change in our communities.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card
              key={index}
              className="group hover-elevate cursor-pointer transition-all duration-200"
              data-testid={`card-service-${index}`}
            >
              <CardContent className="p-6">
                <div className={`mb-4 ${service.color}`}>
                  <service.icon className="h-10 w-10" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {service.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {service.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
