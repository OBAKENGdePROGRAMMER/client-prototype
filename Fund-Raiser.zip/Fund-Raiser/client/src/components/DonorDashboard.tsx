import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useTheme } from "@/components/ThemeProvider";
import DashboardSidebar from "./DashboardSidebar";
import StatCard from "./StatCard";
import { Sun, Moon, Heart, Users, Calendar, TrendingUp, Download, FileText } from "lucide-react";

// todo: remove mock functionality
const mockProjects = [
  { id: "1", name: "STEMI Workshop Series", budget: 50000, spent: 35000, progress: 70 },
  { id: "2", name: "Annual Career Expo 2025", budget: 80000, spent: 25000, progress: 31 },
  { id: "3", name: "Mental Health Initiative", budget: 30000, spent: 28000, progress: 93 },
];

const mockImpactMetrics = [
  { label: "Students Reached", value: "1,248", icon: Users },
  { label: "Mentorship Hours", value: "3,567", icon: Calendar },
  { label: "Events Sponsored", value: "12", icon: Heart },
  { label: "Program Growth", value: "+23%", icon: TrendingUp },
];

export default function DonorDashboard() {
  const { theme, toggleTheme } = useTheme();

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full">
        <DashboardSidebar role="donor" userName="ABC Foundation" />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-4 border-b border-border bg-background">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div>
                <h1 className="text-xl font-bold text-foreground">Donor Dashboard</h1>
                <p className="text-sm text-muted-foreground">Track your impact and contributions</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={toggleTheme} data-testid="button-theme-toggle">
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <Button variant="outline" data-testid="button-section18a">
                <FileText className="h-4 w-4 mr-2" />
                Section 18A
              </Button>
              <Button data-testid="button-donate">
                <Heart className="h-4 w-4 mr-2" />
                Donate
              </Button>
            </div>
          </header>

          <main className="flex-1 overflow-auto p-6">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">
                Thank you for your support
              </h2>
              <p className="text-muted-foreground">
                Your contributions are making a real difference in the lives of South African youth.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {mockImpactMetrics.map((metric, index) => (
                <StatCard
                  key={index}
                  title={metric.label}
                  value={metric.value}
                  icon={metric.icon}
                  iconColor="text-primary"
                />
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                  <CardTitle className="text-lg">Your Contributions</CardTitle>
                  <Button variant="ghost" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-3xl font-bold text-foreground">R 160,000</p>
                        <p className="text-sm text-muted-foreground">Total Contributed</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-semibold text-foreground">R 88,000</p>
                        <p className="text-sm text-muted-foreground">Utilized</p>
                      </div>
                    </div>
                    <Progress value={55} className="h-3" />
                    <p className="text-sm text-muted-foreground">55% of your contributions have been utilized</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Section 18A Certificates</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Download your tax-deductible donation certificates
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <div>
                        <p className="font-medium text-foreground">2024 Annual Certificate</p>
                        <p className="text-sm text-muted-foreground">R 160,000 total donations</p>
                      </div>
                      <Button variant="outline" size="sm" data-testid="button-download-cert-2024">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <div>
                        <p className="font-medium text-foreground">2023 Annual Certificate</p>
                        <p className="text-sm text-muted-foreground">R 120,000 total donations</p>
                      </div>
                      <Button variant="outline" size="sm" data-testid="button-download-cert-2023">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Sponsored Projects</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {mockProjects.map((project) => (
                    <div key={project.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-foreground">{project.name}</h3>
                        <span className="text-sm text-muted-foreground">
                          R {project.spent.toLocaleString()} / R {project.budget.toLocaleString()}
                        </span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                      <p className="text-xs text-muted-foreground">{project.progress}% complete</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
