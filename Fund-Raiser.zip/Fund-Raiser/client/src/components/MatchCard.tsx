import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowRight, Check, X, RefreshCw } from "lucide-react";

interface Person {
  id: string;
  name: string;
  role: string;
  institution: string;
  imageUrl?: string;
}

interface MatchCardProps {
  mentor: Person;
  mentee: Person;
  matchScore: number;
  matchCriteria: string[];
  status: "pending" | "accepted" | "rejected";
  onAccept?: () => void;
  onReject?: () => void;
  onRematch?: () => void;
}

export default function MatchCard({
  mentor,
  mentee,
  matchScore,
  matchCriteria,
  status,
  onAccept,
  onReject,
  onRematch,
}: MatchCardProps) {
  const getInitials = (name: string) =>
    name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

  const PersonCard = ({ person, label }: { person: Person; label: string }) => (
    <div className="flex-1 text-center p-4 rounded-lg bg-muted/50">
      <p className="text-xs text-muted-foreground mb-2">{label}</p>
      <Avatar className="h-16 w-16 mx-auto mb-3">
        <AvatarImage src={person.imageUrl} alt={person.name} />
        <AvatarFallback>{getInitials(person.name)}</AvatarFallback>
      </Avatar>
      <h3 className="font-semibold text-foreground">{person.name}</h3>
      <p className="text-sm text-muted-foreground">{person.role}</p>
      <p className="text-xs text-muted-foreground">{person.institution}</p>
    </div>
  );

  return (
    <Card data-testid={`match-card-${mentor.id}-${mentee.id}`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-4 mb-4">
          <PersonCard person={mentor} label="Mentor" />
          <div className="flex flex-col items-center gap-2">
            <ArrowRight className="h-6 w-6 text-primary" />
            <Badge variant="secondary" className="bg-primary/10 text-primary">
              {matchScore}% Match
            </Badge>
          </div>
          <PersonCard person={mentee} label="Mentee" />
        </div>

        <div className="mb-4">
          <p className="text-sm font-medium text-foreground mb-2">Match Criteria:</p>
          <div className="flex flex-wrap gap-2">
            {matchCriteria.map((criteria, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {criteria}
              </Badge>
            ))}
          </div>
        </div>

        {status === "pending" && (
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              className="flex-1 text-red-600 hover:text-red-700"
              onClick={onReject}
              data-testid="button-reject-match"
            >
              <X className="h-4 w-4 mr-2" />
              Reject
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={onRematch}
              data-testid="button-rematch"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Find Another
            </Button>
            <Button
              className="flex-1"
              onClick={onAccept}
              data-testid="button-accept-match"
            >
              <Check className="h-4 w-4 mr-2" />
              Accept
            </Button>
          </div>
        )}

        {status === "accepted" && (
          <div className="flex items-center justify-center p-3 rounded-md bg-green-500/10 text-green-600">
            <Check className="h-5 w-5 mr-2" />
            <span className="font-medium">Match Accepted</span>
          </div>
        )}

        {status === "rejected" && (
          <div className="flex items-center justify-center p-3 rounded-md bg-red-500/10 text-red-600">
            <X className="h-5 w-5 mr-2" />
            <span className="font-medium">Match Rejected</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
