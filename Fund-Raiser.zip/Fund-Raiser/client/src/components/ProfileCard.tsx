import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageCircle, Calendar, MoreVertical } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ProfileCardProps {
  id: string;
  name: string;
  role: string;
  status: "active" | "pending" | "inactive";
  imageUrl?: string;
  institution?: string;
  matchedWith?: string;
  sessionsCount?: number;
  onMessage?: (id: string) => void;
  onSchedule?: (id: string) => void;
}

const statusColors = {
  active: "bg-green-500/10 text-green-600 dark:text-green-400",
  pending: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
  inactive: "bg-gray-500/10 text-gray-600 dark:text-gray-400",
};

export default function ProfileCard({
  id,
  name,
  role,
  status,
  imageUrl,
  institution,
  matchedWith,
  sessionsCount,
  onMessage,
  onSchedule,
}: ProfileCardProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Card data-testid={`profile-card-${id}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <Avatar className="h-12 w-12">
            <AvatarImage src={imageUrl} alt={name} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-semibold text-foreground truncate">{name}</h3>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>View Profile</DropdownMenuItem>
                  <DropdownMenuItem>View Activity</DropdownMenuItem>
                  <DropdownMenuItem>Generate Report</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <p className="text-sm text-muted-foreground">{role}</p>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Badge variant="secondary" className={statusColors[status]}>
                {status}
              </Badge>
              {institution && (
                <span className="text-xs text-muted-foreground">{institution}</span>
              )}
            </div>
          </div>
        </div>

        {(matchedWith || sessionsCount !== undefined) && (
          <div className="mt-4 pt-4 border-t border-border space-y-2 text-sm">
            {matchedWith && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Matched with:</span>
                <span className="font-medium text-foreground">{matchedWith}</span>
              </div>
            )}
            {sessionsCount !== undefined && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Sessions:</span>
                <span className="font-medium text-foreground">{sessionsCount}</span>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center gap-2 mt-4">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onMessage?.(id)}
            data-testid={`button-message-${id}`}
          >
            <MessageCircle className="h-4 w-4 mr-2" />
            Message
          </Button>
          <Button
            size="sm"
            className="flex-1"
            onClick={() => onSchedule?.(id)}
            data-testid={`button-schedule-${id}`}
          >
            <Calendar className="h-4 w-4 mr-2" />
            Schedule
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
