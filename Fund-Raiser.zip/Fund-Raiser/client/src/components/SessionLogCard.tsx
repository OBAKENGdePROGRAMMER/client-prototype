import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Video, Users, Clock, ChevronDown, ChevronUp, Flag } from "lucide-react";
import { useState } from "react";

interface SessionLogCardProps {
  id: string;
  date: string;
  type: "virtual" | "physical";
  duration: string;
  theme: string;
  notes?: string;
  mentorName?: string;
  menteeName?: string;
  flagged?: boolean;
  onFlag?: (id: string) => void;
}

export default function SessionLogCard({
  id,
  date,
  type,
  duration,
  theme,
  notes,
  mentorName,
  menteeName,
  flagged = false,
  onFlag,
}: SessionLogCardProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <Card className={flagged ? "border-orange-500/50" : ""} data-testid={`session-card-${id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex-shrink-0">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                type === "virtual" ? "bg-blue-500/10 text-blue-600" : "bg-green-500/10 text-green-600"
              }`}>
                {type === "virtual" ? <Video className="h-5 w-5" /> : <Users className="h-5 w-5" />}
              </div>
            </div>
            <div>
              <p className="font-medium text-foreground">{theme}</p>
              <p className="text-sm text-muted-foreground">{date}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {flagged && (
              <Badge variant="destructive" className="bg-orange-500/10 text-orange-600">
                <Flag className="h-3 w-3 mr-1" />
                Flagged
              </Badge>
            )}
            <Badge variant="outline">
              <Clock className="h-3 w-3 mr-1" />
              {duration}
            </Badge>
          </div>
        </div>

        {(mentorName || menteeName) && (
          <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
            {mentorName && <span>Mentor: <span className="font-medium text-foreground">{mentorName}</span></span>}
            {menteeName && <span>Mentee: <span className="font-medium text-foreground">{menteeName}</span></span>}
          </div>
        )}

        {notes && (
          <>
            <Button
              variant="ghost"
              size="sm"
              className="mt-3 w-full justify-between"
              onClick={() => setExpanded(!expanded)}
              data-testid={`button-expand-${id}`}
            >
              <span>Session Notes</span>
              {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>
            {expanded && (
              <div className="mt-2 p-3 rounded-md bg-muted/50 text-sm text-muted-foreground">
                {notes}
              </div>
            )}
          </>
        )}

        {!flagged && onFlag && (
          <Button
            variant="ghost"
            size="sm"
            className="mt-3 text-orange-600 hover:text-orange-700"
            onClick={() => onFlag(id)}
            data-testid={`button-flag-${id}`}
          >
            <Flag className="h-4 w-4 mr-2" />
            Flag for Review
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
