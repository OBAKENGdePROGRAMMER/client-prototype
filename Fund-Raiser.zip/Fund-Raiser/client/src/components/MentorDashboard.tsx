import { useState } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTheme } from "@/components/ThemeProvider";
import DashboardSidebar from "./DashboardSidebar";
import StatCard from "./StatCard";
import ProfileCard from "./ProfileCard";
import SessionLogCard from "./SessionLogCard";
import ResourceCard from "./ResourceCard";
import { Sun, Moon, Users, Calendar, Clock, Award, Plus } from "lucide-react";

// todo: remove mock functionality
const mockMentee = {
  id: "1",
  name: "Thabo Molefe",
  role: "Grade 11 Student",
  status: "active" as const,
  institution: "Pretoria High School",
  matchedWith: "John Smith",
  sessionsCount: 8,
};

const mockSessions = [
  {
    id: "1",
    date: "December 5, 2024",
    type: "virtual" as const,
    duration: "45 mins",
    theme: "Career Planning - Engineering Pathways",
    notes: "Discussed various engineering disciplines and university requirements. Thabo showed strong interest in mechanical engineering.",
    menteeName: "Thabo Molefe",
  },
  {
    id: "2",
    date: "November 28, 2024",
    type: "physical" as const,
    duration: "60 mins",
    theme: "Study Skills - Mathematics Revision",
    notes: "Worked through calculus problems and identified areas for improvement.",
    menteeName: "Thabo Molefe",
  },
  {
    id: "3",
    date: "November 21, 2024",
    type: "virtual" as const,
    duration: "30 mins",
    theme: "Goal Setting & Motivation",
    menteeName: "Thabo Molefe",
    flagged: true,
  },
];

const mockResources = [
  {
    id: "1",
    title: "Effective Mentoring Guide",
    description: "A comprehensive guide on how to be an effective mentor and build meaningful connections with your mentee.",
    type: "pdf" as const,
    category: "general" as const,
    downloadUrl: "#",
  },
  {
    id: "2",
    title: "Study Skills Workshop Recording",
    description: "Recording from our recent workshop on effective study techniques for high school students.",
    type: "video" as const,
    category: "study-skills" as const,
  },
];

export default function MentorDashboard() {
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState("overview");

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  } as React.CSSProperties;

  const handleMessage = (id: string) => console.log(`Message sent to: ${id}`);
  const handleSchedule = (id: string) => console.log(`Schedule session with: ${id}`);
  const handleFlag = (id: string) => console.log(`Flagged session: ${id}`);
  const handleViewResource = (id: string) => console.log(`View resource: ${id}`);

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full">
        <DashboardSidebar role="mentor" userName="John Smith" />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-4 border-b border-border bg-background">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div>
                <h1 className="text-xl font-bold text-foreground">Mentor Dashboard</h1>
                <p className="text-sm text-muted-foreground">Welcome back, John</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={toggleTheme} data-testid="button-theme-toggle">
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <Button data-testid="button-log-session">
                <Plus className="h-4 w-4 mr-2" />
                Log Session
              </Button>
            </div>
          </header>

          <main className="flex-1 overflow-auto p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-6">
                <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
                <TabsTrigger value="sessions" data-testid="tab-sessions">Sessions</TabsTrigger>
                <TabsTrigger value="resources" data-testid="tab-resources">Resources</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    title="Total Sessions"
                    value="12"
                    change={15}
                    changeLabel="this month"
                    icon={Calendar}
                    iconColor="text-blue-500"
                  />
                  <StatCard
                    title="Hours Mentored"
                    value="8.5"
                    change={20}
                    changeLabel="this month"
                    icon={Clock}
                    iconColor="text-green-500"
                  />
                  <StatCard
                    title="Mentee Progress"
                    value="78%"
                    change={5}
                    changeLabel="improvement"
                    icon={Award}
                    iconColor="text-purple-500"
                  />
                  <StatCard
                    title="Active Mentees"
                    value="1"
                    icon={Users}
                    iconColor="text-orange-500"
                  />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                        <CardTitle className="text-lg">Recent Sessions</CardTitle>
                        <Button variant="ghost" size="sm" data-testid="button-view-all-sessions">
                          View All
                        </Button>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {mockSessions.slice(0, 2).map((session) => (
                          <SessionLogCard
                            key={session.id}
                            {...session}
                            onFlag={handleFlag}
                          />
                        ))}
                      </CardContent>
                    </Card>
                  </div>
                  <div>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">My Mentee</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ProfileCard
                          {...mockMentee}
                          onMessage={handleMessage}
                          onSchedule={handleSchedule}
                        />
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="sessions" className="space-y-4">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <h2 className="text-lg font-semibold text-foreground">Session History</h2>
                  <Button data-testid="button-new-session">
                    <Plus className="h-4 w-4 mr-2" />
                    New Session
                  </Button>
                </div>
                {mockSessions.map((session) => (
                  <SessionLogCard key={session.id} {...session} onFlag={handleFlag} />
                ))}
              </TabsContent>

              <TabsContent value="resources" className="space-y-4">
                <h2 className="text-lg font-semibold text-foreground mb-4">Learning Resources</h2>
                {mockResources.map((resource) => (
                  <ResourceCard key={resource.id} {...resource} onView={handleViewResource} />
                ))}
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
