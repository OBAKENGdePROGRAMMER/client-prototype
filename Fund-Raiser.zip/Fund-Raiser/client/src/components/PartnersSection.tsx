const partners = [
  { name: "SMU", type: "University" },
  { name: "Pretoria High", type: "School" },
  { name: "ABC Foundation", type: "Donor" },
  { name: "Tech Corp SA", type: "Sponsor" },
  { name: "Education Dept", type: "Government" },
  { name: "Youth Trust", type: "NPO" },
];

export default function PartnersSection() {
  return (
    <section className="py-12 bg-muted/30 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-sm text-muted-foreground mb-8">
          Trusted by leading institutions and organizations
        </p>
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {partners.map((partner, index) => (
            <div
              key={index}
              className="flex items-center justify-center w-32 h-16 rounded-md bg-background border border-border opacity-70 hover:opacity-100 transition-opacity"
              data-testid={`partner-logo-${index}`}
            >
              <div className="text-center">
                <p className="font-semibold text-foreground text-sm">{partner.name}</p>
                <p className="text-xs text-muted-foreground">{partner.type}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
