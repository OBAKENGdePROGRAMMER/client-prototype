import { useState } from "react";
import { Button } from "@/components/ui/button";
import EventCard, { EventCardProps } from "./EventCard";
import { ArrowRight } from "lucide-react";
import workshopImage from "@assets/generated_images/group_workshop_students_photo.png";

// todo: remove mock functionality
const mockEvents: EventCardProps[] = [
  {
    id: "1",
    title: "ABM Network Launch 2025",
    description: "Join us for the official launch of the Adopt-a-Buddy Mentorship Network platform with keynote speakers and networking.",
    date: "January 25, 2025",
    time: "09:00 - 16:00",
    location: "SMU Main Campus, Pretoria",
    attendees: 180,
    maxAttendees: 200,
    category: "launch",
    imageUrl: workshopImage,
  },
  {
    id: "2",
    title: "STEMI Career Guidance Workshop",
    description: "Explore exciting career paths in Science, Technology, Engineering, Mathematics and Innovation with industry experts.",
    date: "February 8, 2025",
    time: "10:00 - 14:00",
    location: "Virtual Event",
    attendees: 45,
    maxAttendees: 100,
    category: "workshop",
  },
  {
    id: "3",
    title: "Annual Career Expo",
    description: "Connect with top employers and discover internship and graduate opportunities in various STEMI fields.",
    date: "March 15, 2025",
    time: "09:00 - 17:00",
    location: "Johannesburg Convention Centre",
    attendees: 500,
    maxAttendees: 500,
    category: "career-expo",
  },
];

interface EventsSectionProps {
  onViewAll?: () => void;
}

export default function EventsSection({ onViewAll }: EventsSectionProps) {
  const [events] = useState<EventCardProps[]>(mockEvents);

  const handleRSVP = (id: string) => {
    console.log(`RSVP triggered for event: ${id}`);
  };

  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
              Upcoming Events
            </h2>
            <p className="text-lg text-muted-foreground">
              Join our workshops, seminars, and networking events
            </p>
          </div>
          <Button variant="outline" onClick={onViewAll} data-testid="button-view-all-events">
            View All Events
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event) => (
            <EventCard key={event.id} {...event} onRSVP={handleRSVP} />
          ))}
        </div>
      </div>
    </section>
  );
}
