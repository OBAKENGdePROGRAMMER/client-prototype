# ABM Network Design Guidelines

## Design Approach

**Selected Approach:** Design System - Material Design principles with modern nonprofit aesthetics

**Justification:** This is a utility-focused, information-dense platform serving educational purposes with multiple stakeholder dashboards. The system requires professional credibility for NGO funding, consistent patterns across user roles, and clear data hierarchy.

**Key Principles:**
- Trust & Professionalism: Clean, structured layouts that convey organizational credibility
- Role Clarity: Distinct visual patterns for each dashboard type while maintaining system cohesion
- Data Accessibility: Clear information hierarchy optimized for scanning and decision-making
- Inclusive Design: WCAG 2.1 AA compliant throughout

---

## Typography

**Font Families:**
- Primary: Inter (headings, UI elements, data) - clean, professional, excellent readability
- Secondary: System fonts fallback for performance

**Type Scale:**
- Hero/Page Titles: text-4xl md:text-5xl font-bold
- Section Headers: text-2xl md:text-3xl font-semibold
- Card/Component Titles: text-xl font-semibold
- Subsection Headers: text-lg font-medium
- Body Text: text-base (16px)
- Secondary/Meta Text: text-sm
- Captions/Labels: text-xs uppercase tracking-wide

**Hierarchy Rules:**
- Dashboard titles: Bold, large, with subtle divider below
- Data labels: Uppercase, small, medium weight
- Statistics/Metrics: Extra large numbers with small label beneath
- Form labels: Medium weight, comfortable spacing from inputs

---

## Layout System

**Spacing Primitives:** Use Tailwind units of **2, 4, 6, 8, 12, 16** for consistent rhythm
- Component padding: p-4 to p-6
- Section spacing: py-8 to py-16
- Card margins: gap-4 to gap-6
- Dashboard grid gaps: gap-6

**Grid System:**
- Landing: max-w-7xl mx-auto with asymmetric feature grids
- Dashboards: Sidebar (w-64) + Main content area (flex-1) on desktop; full-width stack on mobile
- Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 for stats/metrics
- Forms: max-w-2xl with single-column layout for clarity

**Responsive Breakpoints:**
- Mobile-first approach
- Sidebar collapses to hamburger menu below md:
- Dashboard cards stack to single column on mobile
- Tables convert to scrollable horizontal on mobile

---

## Component Library

### Navigation
**Main Header:** Fixed top navigation with logo left, main menu center, user profile/notifications right. Transparent on landing hero, solid with shadow on scroll and dashboards.

**Dashboard Sidebar:** Collapsible left sidebar with role-based navigation items, icon + label pattern, active state highlight, organization logo at top.

### Landing Page Components

**Hero Section:** Full-width (min-h-screen) with large background image showing diverse mentorship scenes, centered text overlay with blurred-background CTA buttons, scroll indicator at bottom.

**Services Grid:** 2x2 grid showcasing Development (Youth/Student/Community/Sports), Counselling, Coaching, Mentorship with icons and brief descriptions.

**Program Overview:** Alternating left-right layout with text + imagery explaining ABMP structure.

**Impact Metrics:** Centered stats bar with large numbers and labels (mentors registered, sessions completed, schools partnered).

**Partner Logos:** Grid of school and sponsor logos with subtle grayscale treatment.

**Events Preview:** Card carousel showing upcoming events with RSVP quick links.

**Footer:** Multi-column (About, Quick Links, Contact, Social) with newsletter signup and NPO registration numbers.

### Dashboard Components

**Stat Cards:** Rounded corners, subtle shadow, icon top-left, large metric center, trend indicator, label beneath. Use in 3-4 column grids.

**Data Tables:** Clean borders, alternating row backgrounds, sortable headers, action buttons right-aligned, pagination bottom.

**Profile Cards:** Avatar/photo left, name/role/status stacked right, quick actions as icon buttons, expandable details section.

**Session Log Cards:** Timeline layout with date markers, session type badges, duration/theme tags, notes preview with expand option.

**Progress Trackers:** Horizontal stepper for onboarding workflows, circular progress for goal completion, linear bars for attendance metrics.

**Match Display:** Side-by-side mentor/mentee cards with connecting visual element, match criteria tags, acceptance/override buttons.

### Forms & Inputs

**Smart Forms:** Multi-step wizards with progress indicator, role-adaptive field groups, inline validation, file upload with drag-drop zones.

**Input Fields:** Consistent padding (p-3), clear labels above, helper text below, error states with red borders and messages.

**Action Buttons:** Primary (filled), Secondary (outlined), Tertiary (text only). Rounded (rounded-lg), medium padding (px-6 py-3).

**File Upload:** Dashed border dropzone with upload icon, file preview thumbnails, progress indicators, remove option.

### Data Visualization

**Charts:** Clean line/bar charts for session trends, pie charts for distribution metrics, embedded using Chart.js or Recharts.

**Activity Feed:** Vertical timeline with avatars, action descriptions, timestamps, filter options.

**Calendar View:** Month grid for event management, color-coded event types, hover previews, create event quick action.

### Modals & Overlays

**Modals:** Centered overlay with max-w-2xl, close button top-right, clear header/body/footer sections, backdrop blur.

**Notifications:** Toast style top-right, auto-dismiss, status color coding (success/warning/error/info).

**Confirmation Dialogs:** Smaller modals for delete/approve actions, clear consequences stated, prominent cancel option.

---

## Images

**Hero Image:** Large, inspiring photo of diverse young people in mentorship/learning setting - bright, hopeful atmosphere. Full-width, subtle gradient overlay for text readability.

**Section Images:** Use authentic photos showing:
- Mentorship sessions (1-on-1 interactions)
- Group workshops and events
- Students studying/collaborating
- School environments

**Profile Placeholders:** Circular avatars with initials for users without photos.

**Event Cards:** Rectangular event photos with 16:9 aspect ratio.

---

## Animations

**Minimal Motion:**
- Fade-in on scroll for landing page sections (subtle, duration-300)
- Smooth transitions for dashboard sidebar open/close
- Hover lift effect on cards (translate-y-1 + shadow increase)
- Loading spinners for data fetching
- NO complex scroll animations or parallax effects

---

## Accessibility

- All interactive elements keyboard navigable
- Focus states visible with outline offset
- Form inputs with proper ARIA labels
- Sufficient contrast ratios (4.5:1 minimum)
- Screen reader friendly navigation structure
- Error messages programmatically associated with fields