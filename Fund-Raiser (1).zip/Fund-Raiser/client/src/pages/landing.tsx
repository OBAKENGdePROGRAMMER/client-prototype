import { useState, useEffect } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import ProgramOverview from "@/components/ProgramOverview";
import EventsSection from "@/components/EventsSection";
import ImpactMetrics from "@/components/ImpactMetrics";
import PartnersSection from "@/components/PartnersSection";
import Footer from "@/components/Footer";
import RegistrationModal from "@/components/RegistrationModal";
import LoginModal from "@/components/LoginModal";

export default function LandingPage() {
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header
        transparent={!isScrolled}
        onLoginClick={() => setShowLogin(true)}
        onRegisterClick={() => setShowRegister(true)}
      />
      
      <main>
        <HeroSection
          onBecomeMentor={() => setShowRegister(true)}
          onLearnMore={() => {
            const element = document.getElementById("about");
            element?.scrollIntoView({ behavior: "smooth" });
          }}
        />
        
        <div id="about">
          <ProgramOverview onJoinProgram={() => setShowRegister(true)} />
        </div>
        
        <ServicesSection />
        
        <EventsSection onViewAll={() => console.log("View all events")} />
        
        <ImpactMetrics />
        
        <PartnersSection />
      </main>
      
      <Footer />
      
      <LoginModal
        open={showLogin}
        onOpenChange={setShowLogin}
        onRegisterClick={() => {
          setShowLogin(false);
          setShowRegister(true);
        }}
      />
      
      <RegistrationModal
        open={showRegister}
        onOpenChange={setShowRegister}
      />
    </div>
  );
}
