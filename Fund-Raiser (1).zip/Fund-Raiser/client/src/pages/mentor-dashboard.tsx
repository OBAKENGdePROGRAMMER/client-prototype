import MentorDashboard from "@/components/MentorDashboard";

export default function MentorDashboardPage() {
  return <MentorDashboard />;
}
