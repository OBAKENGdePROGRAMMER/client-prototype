import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Users,
  Calendar,
  MessageCircle,
  BookOpen,
  BarChart3,
  Settings,
  LogOut,
  FileText,
  Bell,
  UserPlus,
  Heart,
  AlertTriangle,
  Building,
} from "lucide-react";

type UserRole = "mentor" | "mentee" | "school" | "psychology" | "smu" | "donor" | "admin";

interface DashboardSidebarProps {
  role: UserRole;
  userName?: string;
  userImage?: string;
}

const menuItems: Record<UserRole, { icon: React.ComponentType<{ className?: string }>; label: string; href: string }[]> = {
  mentor: [
    { icon: LayoutDashboard, label: "Overview", href: "/dashboard/mentor" },
    { icon: Users, label: "My Mentee", href: "/dashboard/mentor/mentee" },
    { icon: Calendar, label: "Sessions", href: "/dashboard/mentor/sessions" },
    { icon: MessageCircle, label: "Messages", href: "/dashboard/mentor/messages" },
    { icon: BookOpen, label: "Resources", href: "/dashboard/mentor/resources" },
    { icon: BarChart3, label: "Progress", href: "/dashboard/mentor/progress" },
  ],
  mentee: [
    { icon: LayoutDashboard, label: "Overview", href: "/dashboard/mentee" },
    { icon: Users, label: "My Mentor", href: "/dashboard/mentee/mentor" },
    { icon: Calendar, label: "Sessions", href: "/dashboard/mentee/sessions" },
    { icon: MessageCircle, label: "Messages", href: "/dashboard/mentee/messages" },
    { icon: BookOpen, label: "Resources", href: "/dashboard/mentee/resources" },
    { icon: BarChart3, label: "My Progress", href: "/dashboard/mentee/progress" },
  ],
  school: [
    { icon: LayoutDashboard, label: "Overview", href: "/dashboard/school" },
    { icon: Users, label: "Learners", href: "/dashboard/school/learners" },
    { icon: UserPlus, label: "Approvals", href: "/dashboard/school/approvals" },
    { icon: FileText, label: "Reports", href: "/dashboard/school/reports" },
    { icon: BarChart3, label: "Analytics", href: "/dashboard/school/analytics" },
  ],
  psychology: [
    { icon: LayoutDashboard, label: "Overview", href: "/dashboard/psychology" },
    { icon: AlertTriangle, label: "Risk Alerts", href: "/dashboard/psychology/alerts" },
    { icon: Users, label: "Cases", href: "/dashboard/psychology/cases" },
    { icon: FileText, label: "Reports", href: "/dashboard/psychology/reports" },
    { icon: Calendar, label: "Activity Log", href: "/dashboard/psychology/activity" },
  ],
  smu: [
    { icon: LayoutDashboard, label: "Overview", href: "/dashboard/smu" },
    { icon: Building, label: "Faculty View", href: "/dashboard/smu/faculty" },
    { icon: UserPlus, label: "Verifications", href: "/dashboard/smu/verifications" },
    { icon: FileText, label: "Reports", href: "/dashboard/smu/reports" },
  ],
  donor: [
    { icon: LayoutDashboard, label: "Overview", href: "/dashboard/donor" },
    { icon: BarChart3, label: "Impact", href: "/dashboard/donor/impact" },
    { icon: Calendar, label: "Events", href: "/dashboard/donor/events" },
    { icon: Heart, label: "Contributions", href: "/dashboard/donor/contributions" },
    { icon: FileText, label: "Section 18A", href: "/dashboard/donor/section18a" },
  ],
  admin: [
    { icon: LayoutDashboard, label: "Overview", href: "/dashboard/admin" },
    { icon: Users, label: "Users", href: "/dashboard/admin/users" },
    { icon: UserPlus, label: "Approvals", href: "/dashboard/admin/approvals" },
    { icon: Calendar, label: "Events", href: "/dashboard/admin/events" },
    { icon: BarChart3, label: "M&E Dashboard", href: "/dashboard/admin/analytics" },
    { icon: FileText, label: "Documents", href: "/dashboard/admin/documents" },
    { icon: Bell, label: "Communications", href: "/dashboard/admin/communications" },
    { icon: Settings, label: "Settings", href: "/dashboard/admin/settings" },
  ],
};

const roleLabels: Record<UserRole, string> = {
  mentor: "Mentor",
  mentee: "Mentee",
  school: "School Staff",
  psychology: "Psychology Intern",
  smu: "SMU Department",
  donor: "Donor",
  admin: "Administrator",
};

export default function DashboardSidebar({ role, userName = "User", userImage }: DashboardSidebarProps) {
  const [location] = useLocation();
  const items = menuItems[role];
  const initials = userName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-md bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">A</span>
          </div>
          <div>
            <span className="font-bold text-sidebar-foreground">ABM Network</span>
            <p className="text-xs text-muted-foreground">{roleLabels[role]}</p>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.href}
                  >
                    <Link href={item.href} data-testid={`sidebar-${item.label.toLowerCase().replace(/\s+/g, "-")}`}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 mb-3">
          <Avatar className="h-9 w-9">
            <AvatarImage src={userImage} alt={userName} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">{userName}</p>
            <p className="text-xs text-muted-foreground">{roleLabels[role]}</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" className="w-full justify-start" data-testid="button-logout">
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
