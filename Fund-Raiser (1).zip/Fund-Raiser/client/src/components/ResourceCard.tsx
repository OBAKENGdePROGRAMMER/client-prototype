import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Video, Download, BookOpen, ExternalLink } from "lucide-react";

interface ResourceCardProps {
  id: string;
  title: string;
  description: string;
  type: "pdf" | "video" | "toolkit" | "article";
  category: "study-skills" | "mental-health" | "career-guidance" | "general";
  downloadUrl?: string;
  onView?: (id: string) => void;
}

const typeIcons = {
  pdf: FileText,
  video: Video,
  toolkit: BookOpen,
  article: ExternalLink,
};

const typeColors = {
  pdf: "text-red-500",
  video: "text-blue-500",
  toolkit: "text-purple-500",
  article: "text-green-500",
};

const categoryLabels = {
  "study-skills": "Study Skills",
  "mental-health": "Mental Health",
  "career-guidance": "Career Guidance",
  general: "General",
};

export default function ResourceCard({
  id,
  title,
  description,
  type,
  category,
  downloadUrl,
  onView,
}: ResourceCardProps) {
  const Icon = typeIcons[type];

  return (
    <Card className="hover-elevate" data-testid={`resource-card-${id}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <div className={`p-3 rounded-lg bg-muted ${typeColors[type]}`}>
            <Icon className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <h3 className="font-semibold text-foreground">{title}</h3>
              <Badge variant="outline" className="text-xs">
                {categoryLabels[category]}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {description}
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onView?.(id)}
                data-testid={`button-view-resource-${id}`}
              >
                View
              </Button>
              {downloadUrl && (
                <Button
                  variant="ghost"
                  size="sm"
                  asChild
                  data-testid={`button-download-resource-${id}`}
                >
                  <a href={downloadUrl} download>
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </a>
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
