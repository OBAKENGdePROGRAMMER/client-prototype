import { ThemeProvider } from "../ThemeProvider";
import ProfileCard from "../ProfileCard";

export default function ProfileCardExample() {
  return (
    <ThemeProvider>
      <div className="max-w-sm">
        <ProfileCard
          id="1"
          name="John Smith"
          role="3rd Year Engineering Student"
          status="active"
          institution="SMU"
          matchedWith="Thabo Molefe"
          sessionsCount={8}
          onMessage={(id) => console.log(`Message: ${id}`)}
          onSchedule={(id) => console.log(`Schedule: ${id}`)}
        />
      </div>
    </ThemeProvider>
  );
}
