import { ThemeProvider } from "../ThemeProvider";
import MentorDashboard from "../MentorDashboard";

export default function MentorDashboardExample() {
  return (
    <ThemeProvider>
      <MentorDashboard />
    </ThemeProvider>
  );
}
