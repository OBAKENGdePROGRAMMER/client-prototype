import { ThemeProvider } from "../ThemeProvider";
import EventCard from "../EventCard";

export default function EventCardExample() {
  return (
    <ThemeProvider>
      <div className="max-w-md">
        <EventCard
          id="1"
          title="ABM Network Launch 2025"
          description="Join us for the official launch of the Adopt-a-Buddy Mentorship Network platform."
          date="January 25, 2025"
          time="09:00 - 16:00"
          location="SMU Main Campus, Pretoria"
          attendees={180}
          maxAttendees={200}
          category="launch"
          onRSVP={(id) => console.log(`RSVP for event: ${id}`)}
        />
      </div>
    </ThemeProvider>
  );
}
