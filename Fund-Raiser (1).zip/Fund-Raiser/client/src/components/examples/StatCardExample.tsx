import { ThemeProvider } from "../ThemeProvider";
import StatCard from "../StatCard";
import { Users } from "lucide-react";

export default function StatCardExample() {
  return (
    <ThemeProvider>
      <div className="max-w-xs">
        <StatCard
          title="Total Mentors"
          value="254"
          change={12}
          changeLabel="this month"
          icon={Users}
          iconColor="text-blue-500"
        />
      </div>
    </ThemeProvider>
  );
}
