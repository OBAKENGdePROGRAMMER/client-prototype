import { Button } from "@/components/ui/button";
import { ArrowRight, Users, Calendar, BookOpen } from "lucide-react";
import heroImage from "@assets/generated_images/diverse_mentorship_hero_image.png";

interface HeroSectionProps {
  onBecomeMentor?: () => void;
  onLearnMore?: () => void;
}

export default function HeroSection({ onBecomeMentor, onLearnMore }: HeroSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-8">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-white/90 text-sm font-medium">NPO Reg: 288-730 | PBO: 930081137</span>
        </div>
        
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
          Adopt-a-Buddy
          <br />
          <span className="text-primary-foreground">Mentorship Program</span>
        </h1>
        
        <p className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto mb-8">
          Connecting passionate mentors with aspiring youth to build a dynamic society 
          through STEMI education, community development, and transformative mentorship.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <Button
            size="lg"
            onClick={onBecomeMentor}
            className="min-w-[200px]"
            data-testid="button-become-mentor"
          >
            Become a Mentor
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button
            variant="outline"
            size="lg"
            onClick={onLearnMore}
            className="min-w-[200px] bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
            data-testid="button-learn-more"
          >
            Learn More
          </Button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
          <div className="flex flex-col items-center p-6 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20">
            <Users className="h-8 w-8 text-white mb-3" />
            <span className="text-3xl font-bold text-white">250+</span>
            <span className="text-white/70 text-sm">Active Mentors</span>
          </div>
          <div className="flex flex-col items-center p-6 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20">
            <BookOpen className="h-8 w-8 text-white mb-3" />
            <span className="text-3xl font-bold text-white">1,200+</span>
            <span className="text-white/70 text-sm">Mentees Supported</span>
          </div>
          <div className="flex flex-col items-center p-6 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20">
            <Calendar className="h-8 w-8 text-white mb-3" />
            <span className="text-3xl font-bold text-white">85+</span>
            <span className="text-white/70 text-sm">Events Hosted</span>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-8 h-12 rounded-full border-2 border-white/50 flex items-start justify-center pt-2">
          <div className="w-1 h-3 bg-white/70 rounded-full" />
        </div>
      </div>
    </section>
  );
}
