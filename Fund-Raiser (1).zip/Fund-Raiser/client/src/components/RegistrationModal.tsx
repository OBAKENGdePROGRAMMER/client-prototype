import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Users, GraduationCap, Building, Stethoscope, Building2, Heart, Shield } from "lucide-react";

type Role = "mentor" | "mentee" | "school" | "psychology" | "smu" | "donor" | "admin";

interface RegistrationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const roles: { id: Role; label: string; icon: React.ComponentType<{ className?: string }>; description: string }[] = [
  { id: "mentor", label: "Mentor", icon: Users, description: "Guide and support mentees" },
  { id: "mentee", label: "Mentee", icon: GraduationCap, description: "Receive mentorship support" },
  { id: "school", label: "School Staff", icon: Building, description: "Manage school participants" },
  { id: "psychology", label: "Psychology Intern", icon: Stethoscope, description: "Provide psychosocial support" },
  { id: "smu", label: "SMU Department", icon: Building2, description: "University department rep" },
  { id: "donor", label: "Donor/Sponsor", icon: Heart, description: "Support the program" },
  { id: "admin", label: "Admin", icon: Shield, description: "Platform administrator" },
];

export default function RegistrationModal({ open, onOpenChange }: RegistrationModalProps) {
  const [step, setStep] = useState(1);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    institution: "",
    faculty: "",
    year: "",
    availability: "",
    motivation: "",
    consent: false,
  });

  const totalSteps = 3;
  const progress = (step / totalSteps) * 100;

  const handleNext = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = () => {
    console.log("Registration submitted:", { role: selectedRole, ...formData });
    onOpenChange(false);
    setStep(1);
    setSelectedRole(null);
  };

  const updateFormData = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Join ABM Network</DialogTitle>
          <DialogDescription>
            Complete your registration to become part of the Adopt-a-Buddy Mentorship Program
          </DialogDescription>
        </DialogHeader>

        <div className="mb-6">
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
            <span>Step {step} of {totalSteps}</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {step === 1 && (
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">Select your role</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {roles.map((role) => (
                <button
                  key={role.id}
                  onClick={() => setSelectedRole(role.id)}
                  className={`p-4 rounded-lg border text-left transition-all ${
                    selectedRole === role.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  }`}
                  data-testid={`role-${role.id}`}
                >
                  <role.icon className={`h-6 w-6 mb-2 ${
                    selectedRole === role.id ? "text-primary" : "text-muted-foreground"
                  }`} />
                  <p className="font-medium text-sm text-foreground">{role.label}</p>
                  <p className="text-xs text-muted-foreground">{role.description}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">Personal Information</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => updateFormData("firstName", e.target.value)}
                  placeholder="Enter your first name"
                  data-testid="input-first-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => updateFormData("lastName", e.target.value)}
                  placeholder="Enter your last name"
                  data-testid="input-last-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateFormData("email", e.target.value)}
                  placeholder="your.email@example.com"
                  data-testid="input-email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => updateFormData("phone", e.target.value)}
                  placeholder="+27 XX XXX XXXX"
                  data-testid="input-phone"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="institution">Institution</Label>
                <Input
                  id="institution"
                  value={formData.institution}
                  onChange={(e) => updateFormData("institution", e.target.value)}
                  placeholder="University or School name"
                  data-testid="input-institution"
                />
              </div>
              {selectedRole === "mentor" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="faculty">Faculty/Department</Label>
                    <Select
                      value={formData.faculty}
                      onValueChange={(value) => updateFormData("faculty", value)}
                    >
                      <SelectTrigger data-testid="select-faculty">
                        <SelectValue placeholder="Select faculty" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="science">Science</SelectItem>
                        <SelectItem value="engineering">Engineering</SelectItem>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="mathematics">Mathematics</SelectItem>
                        <SelectItem value="health">Health Sciences</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year">Year of Study</Label>
                    <Select
                      value={formData.year}
                      onValueChange={(value) => updateFormData("year", value)}
                    >
                      <SelectTrigger data-testid="select-year">
                        <SelectValue placeholder="Select year" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2">2nd Year</SelectItem>
                        <SelectItem value="3">3rd Year</SelectItem>
                        <SelectItem value="4">4th Year</SelectItem>
                        <SelectItem value="postgrad">Postgraduate</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">Additional Details</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="availability">Availability</Label>
                <Select
                  value={formData.availability}
                  onValueChange={(value) => updateFormData("availability", value)}
                >
                  <SelectTrigger data-testid="select-availability">
                    <SelectValue placeholder="Select your availability" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekday-morning">Weekday Mornings</SelectItem>
                    <SelectItem value="weekday-afternoon">Weekday Afternoons</SelectItem>
                    <SelectItem value="weekday-evening">Weekday Evenings</SelectItem>
                    <SelectItem value="weekend">Weekends</SelectItem>
                    <SelectItem value="flexible">Flexible</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="motivation">Why do you want to join?</Label>
                <Textarea
                  id="motivation"
                  value={formData.motivation}
                  onChange={(e) => updateFormData("motivation", e.target.value)}
                  placeholder="Tell us about your motivation to join the program..."
                  rows={4}
                  data-testid="textarea-motivation"
                />
              </div>
              <div className="flex items-start gap-3 p-4 rounded-lg bg-muted/50">
                <Checkbox
                  id="consent"
                  checked={formData.consent}
                  onCheckedChange={(checked) => updateFormData("consent", checked as boolean)}
                  data-testid="checkbox-consent"
                />
                <div>
                  <Label htmlFor="consent" className="text-sm font-normal cursor-pointer">
                    I agree to the Terms and Conditions and consent to the processing of my 
                    personal information in accordance with the POPIA.
                  </Label>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between gap-4 mt-6 pt-4 border-t border-border">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === 1}
            data-testid="button-back"
          >
            Back
          </Button>
          {step < totalSteps ? (
            <Button
              onClick={handleNext}
              disabled={step === 1 && !selectedRole}
              data-testid="button-next"
            >
              Continue
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={!formData.consent}
              data-testid="button-submit-registration"
            >
              Complete Registration
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
