import { useState } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useTheme } from "@/components/ThemeProvider";
import DashboardSidebar from "./DashboardSidebar";
import StatCard from "./StatCard";
import ProfileCard from "./ProfileCard";
import SessionLogCard from "./SessionLogCard";
import ResourceCard from "./ResourceCard";
import { Sun, Moon, Calendar, Clock, Target, BookOpen } from "lucide-react";

// todo: remove mock functionality
const mockMentor = {
  id: "1",
  name: "John Smith",
  role: "3rd Year Engineering Student",
  status: "active" as const,
  institution: "SMU",
  matchedWith: "Thabo Molefe",
  sessionsCount: 8,
};

const mockSessions = [
  {
    id: "1",
    date: "December 5, 2024",
    type: "virtual" as const,
    duration: "45 mins",
    theme: "Career Planning - Engineering Pathways",
    notes: "Discussed various engineering disciplines and university requirements.",
    mentorName: "John Smith",
  },
  {
    id: "2",
    date: "November 28, 2024",
    type: "physical" as const,
    duration: "60 mins",
    theme: "Study Skills - Mathematics Revision",
    mentorName: "John Smith",
  },
];

const mockResources = [
  {
    id: "1",
    title: "Grade 11 Mathematics Study Guide",
    description: "Comprehensive study guide covering all Grade 11 mathematics topics.",
    type: "pdf" as const,
    category: "study-skills" as const,
    downloadUrl: "#",
  },
  {
    id: "2",
    title: "Managing Exam Stress",
    description: "Tips and techniques for managing stress during exam periods.",
    type: "article" as const,
    category: "mental-health" as const,
  },
];

const mockGoals = [
  { id: "1", title: "Improve Mathematics Grade", progress: 75, target: "From C to B" },
  { id: "2", title: "University Application Prep", progress: 40, target: "Complete by March" },
  { id: "3", title: "Career Research", progress: 90, target: "Explore 5 fields" },
];

export default function MenteeDashboard() {
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState("overview");

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  } as React.CSSProperties;

  const handleMessage = (id: string) => console.log(`Message sent to: ${id}`);
  const handleSchedule = (id: string) => console.log(`Schedule session with: ${id}`);
  const handleViewResource = (id: string) => console.log(`View resource: ${id}`);

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full">
        <DashboardSidebar role="mentee" userName="Thabo Molefe" />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-4 border-b border-border bg-background">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <div>
                <h1 className="text-xl font-bold text-foreground">My Dashboard</h1>
                <p className="text-sm text-muted-foreground">Welcome back, Thabo</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={toggleTheme} data-testid="button-theme-toggle">
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </header>

          <main className="flex-1 overflow-auto p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-6">
                <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
                <TabsTrigger value="sessions" data-testid="tab-sessions">Sessions</TabsTrigger>
                <TabsTrigger value="goals" data-testid="tab-goals">My Goals</TabsTrigger>
                <TabsTrigger value="resources" data-testid="tab-resources">Resources</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    title="Sessions Attended"
                    value="8"
                    change={2}
                    changeLabel="this month"
                    icon={Calendar}
                    iconColor="text-blue-500"
                  />
                  <StatCard
                    title="Total Hours"
                    value="6.5"
                    change={1.5}
                    changeLabel="this month"
                    icon={Clock}
                    iconColor="text-green-500"
                  />
                  <StatCard
                    title="Goals Progress"
                    value="68%"
                    change={12}
                    changeLabel="improvement"
                    icon={Target}
                    iconColor="text-purple-500"
                  />
                  <StatCard
                    title="Resources Accessed"
                    value="15"
                    icon={BookOpen}
                    iconColor="text-orange-500"
                  />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-6">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                        <CardTitle className="text-lg">Recent Sessions</CardTitle>
                        <Button variant="ghost" size="sm">View All</Button>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {mockSessions.map((session) => (
                          <SessionLogCard key={session.id} {...session} />
                        ))}
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">My Goals</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {mockGoals.map((goal) => (
                          <div key={goal.id} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <h3 className="font-medium text-foreground">{goal.title}</h3>
                              <span className="text-sm text-muted-foreground">{goal.target}</span>
                            </div>
                            <Progress value={goal.progress} className="h-2" />
                            <p className="text-xs text-muted-foreground">{goal.progress}% complete</p>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </div>

                  <div>
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">My Mentor</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ProfileCard
                          {...mockMentor}
                          onMessage={handleMessage}
                          onSchedule={handleSchedule}
                        />
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="sessions" className="space-y-4">
                <h2 className="text-lg font-semibold text-foreground mb-4">Session History</h2>
                {mockSessions.map((session) => (
                  <SessionLogCard key={session.id} {...session} />
                ))}
              </TabsContent>

              <TabsContent value="goals" className="space-y-6">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <h2 className="text-lg font-semibold text-foreground">My Goals</h2>
                  <Button data-testid="button-add-goal">Add Goal</Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {mockGoals.map((goal) => (
                    <Card key={goal.id}>
                      <CardContent className="p-6">
                        <h3 className="text-lg font-semibold text-foreground mb-2">{goal.title}</h3>
                        <p className="text-sm text-muted-foreground mb-4">Target: {goal.target}</p>
                        <Progress value={goal.progress} className="h-3 mb-2" />
                        <p className="text-sm text-muted-foreground">{goal.progress}% complete</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="resources" className="space-y-4">
                <h2 className="text-lg font-semibold text-foreground mb-4">Learning Resources</h2>
                {mockResources.map((resource) => (
                  <ResourceCard key={resource.id} {...resource} onView={handleViewResource} />
                ))}
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
