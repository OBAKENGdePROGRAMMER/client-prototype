import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Users, Clock } from "lucide-react";

export interface EventCardProps {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  maxAttendees: number;
  category: "workshop" | "seminar" | "career-expo" | "launch";
  imageUrl?: string;
  onRSVP?: (id: string) => void;
}

const categoryColors: Record<EventCardProps["category"], string> = {
  workshop: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  seminar: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
  "career-expo": "bg-green-500/10 text-green-600 dark:text-green-400",
  launch: "bg-orange-500/10 text-orange-600 dark:text-orange-400",
};

const categoryLabels: Record<EventCardProps["category"], string> = {
  workshop: "Workshop",
  seminar: "Seminar",
  "career-expo": "Career Expo",
  launch: "Launch Event",
};

export default function EventCard({
  id,
  title,
  description,
  date,
  time,
  location,
  attendees,
  maxAttendees,
  category,
  imageUrl,
  onRSVP,
}: EventCardProps) {
  const spotsLeft = maxAttendees - attendees;
  const isFull = spotsLeft <= 0;

  return (
    <Card className="overflow-hidden hover-elevate" data-testid={`card-event-${id}`}>
      {imageUrl && (
        <div className="aspect-video w-full overflow-hidden">
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardContent className="p-4">
        <div className="flex items-center justify-between gap-2 mb-3">
          <Badge variant="secondary" className={categoryColors[category]}>
            {categoryLabels[category]}
          </Badge>
          {isFull ? (
            <Badge variant="destructive">Full</Badge>
          ) : (
            <Badge variant="outline">{spotsLeft} spots left</Badge>
          )}
        </div>
        
        <h3 className="text-lg font-semibold text-foreground mb-2 line-clamp-2">
          {title}
        </h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {description}
        </p>

        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span>{date}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>{time}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span className="line-clamp-1">{location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span>{attendees} / {maxAttendees} registered</span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button
          className="w-full"
          disabled={isFull}
          onClick={() => onRSVP?.(id)}
          data-testid={`button-rsvp-${id}`}
        >
          {isFull ? "Event Full" : "RSVP Now"}
        </Button>
      </CardFooter>
    </Card>
  );
}
