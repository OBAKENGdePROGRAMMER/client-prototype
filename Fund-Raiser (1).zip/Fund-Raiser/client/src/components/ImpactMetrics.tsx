import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";

interface Metric {
  label: string;
  value: string;
  change: number;
  changeLabel: string;
}

// todo: remove mock functionality
const metrics: Metric[] = [
  { label: "Mentors Onboarded", value: "254", change: 12, changeLabel: "vs last month" },
  { label: "Active Mentees", value: "1,248", change: 8, changeLabel: "vs last month" },
  { label: "Sessions Completed", value: "3,567", change: 23, changeLabel: "vs last quarter" },
  { label: "Partner Schools", value: "42", change: 5, changeLabel: "new this year" },
  { label: "Volunteer Hours", value: "12,450", change: 15, changeLabel: "vs last year" },
  { label: "Events Hosted", value: "86", change: -2, changeLabel: "vs last year" },
];

export default function ImpactMetrics() {
  return (
    <section className="py-16 md:py-24 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Our Impact
          </h2>
          <p className="text-lg opacity-80 max-w-2xl mx-auto">
            Measuring the difference we make in communities across South Africa
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {metrics.map((metric, index) => (
            <Card
              key={index}
              className="bg-white/10 border-white/20 backdrop-blur-sm"
              data-testid={`metric-card-${index}`}
            >
              <CardContent className="p-4 text-center">
                <p className="text-3xl md:text-4xl font-bold text-white mb-1">
                  {metric.value}
                </p>
                <p className="text-sm text-white/80 mb-2">{metric.label}</p>
                <div className={`flex items-center justify-center gap-1 text-xs ${
                  metric.change >= 0 ? "text-green-300" : "text-red-300"
                }`}>
                  {metric.change >= 0 ? (
                    <TrendingUp className="h-3 w-3" />
                  ) : (
                    <TrendingDown className="h-3 w-3" />
                  )}
                  <span>{Math.abs(metric.change)}% {metric.changeLabel}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
